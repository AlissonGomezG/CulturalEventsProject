/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ucr.ac.cr.culturalevents;

/**
 *
 * @author allis
 */
public class CulturalEvents {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
